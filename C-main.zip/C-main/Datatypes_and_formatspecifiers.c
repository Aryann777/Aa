//Datatypes and Format specifiers
#include<stdio.h>
int main ()
{
int a=2;
float b=5.2;
double c=5.3;
char z='d';
printf("Value of a(int)is %d",a);
printf("\nValue of b(float)is %f",b);
printf("\nValue of c(Double)is %lf",c);
printf("\nValue of z(char)is %c",z);
return 0;
}