//print numbers from 1 to 5 using for loop
#include<stdio.h>
int main ()
{
int i;
for(i=1;i<=5;i++)
printf("%d\t",i);
return 0;
}