//Test the concept of post increment
#include<stdio.h>
int main()
{
 int i=20;
 printf("i before increment is %d",i);
 printf("\ni after post increment is %d",i++);
 printf("\ni just post increment is %d",i);
 return 0;
}