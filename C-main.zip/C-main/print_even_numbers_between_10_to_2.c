//print numbers from 10 to 2 using while loop
#include <stdio.h>
int main()
{
 int i;
 i=10;
 while(i>=2)
{
 printf("%d\t",i);
 i=i-2;
}
return 0;
}