#include <stdio.h>
int main()
{
int l,s,k=0;
for(l=1;l<=3;l++)
{
 s=1;
 while(s<=l)
 {printf("%d",k=k+2);
 s++;
 }
 printf("\n");
}
return 0;
}
