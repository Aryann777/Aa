//Address of variable
#include<stdio.h>
int main ()
{
int a;
a=10;
printf("Value of a is %p",&a);
a=20;
printf("\nValue of a is now %p",&a);
return 0;

}