//Read two number from user and print their sum
#include<stdio.h>
int main ()
{
int a,b;
printf("Enter two number");
scanf("%d%d",&a,&b);
printf("Sum of both number is %d",a+b);
return 0;
}