//print even numbers from 0 to 10 using for loop
#include<stdio.h>

int main ()
{
int i;
for(i=0;i<=10;i=i+2)
printf("%d\t",i);
return 0;
}