//Use of Tab Character
#include<stdio.h>
int main ()
{
printf("Hi\t");
printf("World");
return 0;
}