//Use of End line
#include<stdio.h>

int main ()
{
printf("Hi\n");
printf("World");
return 0;
}