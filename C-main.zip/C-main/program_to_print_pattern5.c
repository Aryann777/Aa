#include<stdio.h>
int main()
{
 int l,s,k=1;
 for(l=1;l<=3;l++)
 {for(s=1;s<=l;s++)
 printf("%d",k++);
 printf("\n");
 }
 return 0;
}