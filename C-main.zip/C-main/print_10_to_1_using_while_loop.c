//print numbers from 10 to 1 using while loop
#include <stdio.h>
int main()
{
 int i;
 i=10;
 while(i>=1)
{
 printf("%d\t",i);
 i--;
}
return 0;
}