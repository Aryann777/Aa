//Test the concept of pre increment
#include<stdio.h>
Int main()
{
Int i=10;
printf(“i before increment is %d\n”,i);
printf(“i after pre increment is %d\n”,++i);
printf(“i just after pre increment is %d\n.”,i);
Return 0;
}