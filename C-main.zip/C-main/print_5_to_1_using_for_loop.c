//print numbers from 5 to 1 using for loop
#include<stdio.h>
int main ()
{
int i;
for(i=5;i>=1;i--)
printf("%d\t",i);
return 0;
}