#include<stdio.h>
int main()
{
 int l,s;
 for(l=3;l>=1;l--)
 {for(s=1;s<=l;s++)
 printf("*");
 printf("\n");
 }
 return 0;
}