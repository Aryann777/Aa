//size of datatypes using the sizeof function
#include<stdio.h>
int main ()
{
printf("Size of INT is %ld",sizeof(int));
printf("\nSize of CHAR is %ld",sizeof(char));
printf("\nSize of FLOAT is %ld",sizeof(float));
printf("\nSize of DOUBLE is %ld",sizeof(double));
return 0;
}