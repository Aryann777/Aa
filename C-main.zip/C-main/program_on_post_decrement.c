//Test the concept of post decrement
#include<stdio.h>
Int main()
{
Int i=10;
printf(“i before decrement is %d\n”,i);
printf(“i after post decrement is %d\n”,i-- );
printf(“i just after post decrement is %d\n.”,i);
Return 0;
}
