//variables and Datatypes
#include<stdio.h>
int main ()
{
int a;
a=10;
printf("Value of a is %d",a);
return 0;

}