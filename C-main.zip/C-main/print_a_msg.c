#include<stdio.h>
int main ()
{
printf("Hi"); //This is to be printed
return 0;
}